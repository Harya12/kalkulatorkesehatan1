package com.theheran.desaindasboardandroid;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    //Deklarasi Tombol
    Button btn_timbangan,btnair,btnkalori,btnbb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Get ID tombol & Event Tombol
        btn_timbangan= (Button) findViewById(R.id.btn_timbangan);
        btn_timbangan.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Anda Menekan Tombol Timbangan",
                        Toast.LENGTH_SHORT).show();

            } });

        btnair= (Button) findViewById(R.id.btnair);
        btnair.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Anda Menekan Tombol Asupan Air",
                        Toast.LENGTH_SHORT).show();

            } });

        btnkalori= (Button) findViewById(R.id.btnkalori);
        btnkalori.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Anda Menekan Tombol Kalori",
                        Toast.LENGTH_SHORT).show();

            } });

        btnbb= (Button) findViewById(R.id.btnbb);
        btnbb.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Anda Menekan Tombol Berat Badan",
                        Toast.LENGTH_SHORT).show();

            } });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.layout.activity_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;

        }
        return super.onOptionsItemSelected(item);
    }
}
